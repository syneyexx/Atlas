## 0.5.0

- Datasets-pagina onder Data met bibliotheeksidebar en importconsole.
- Interactieve importsimulatie, controle/registratiefasen, pauze/hervatten/annuleren.
- Details, zoeken, typefilter, collecties, opslag, lijst/raster en logexport.
- Brain Graphics mockdata en trace-demo opgenomen.
- Chat en Research behouden.

# 0.3.0

- Research toegevoegd onder hoofdnavigatie Data en submenu Research.
- Onderzoeksopdrachten, bijlagemetadata en lokale wachtrij toegevoegd.
- Uitvoeringsterminal met voorbeeldlogs, echte lokale wachtrijlogs, details, kopiëren, vastzetten, auto-scroll en vergroting.
- Bestaande Chat, model/startpagina en overige tabs behouden.
- ID-generatie hersteld voor HTTP-previewomgevingen.

# 0.2.0

- Goedgekeurde Obsidian Atlas-chatpagina toegevoegd.
- React-componenten voor het gesprek en het Atlas-merk los opgebouwd.
- Tijdweergave, callout, gebruikersballonnen en antwoordacties toegevoegd.
- Voorbeeldgesprek direct zichtbaar zonder gesimuleerde modelverbinding.
- Start-/modelpagina en volledige navigatie behouden.
- Tekstbijlagen, opnieuw genereren en annuleren aangesloten op de runtime-adapter.
- Desktopindeling nauwkeurig afgemeten; mobiel en tablet visueel gecontroleerd.
