import type {Snapshot} from './types';
// Synthetic records use the field names of Atlas' Rust store/API records.
const created_at='2026-10-22T12:00:00Z';
const specs=[
 ['semantic','Hybride retrieval','Atlas combineert vector recall, FTS/BM25 en recency.',['retrieval','architectuur']],
 ['episodic','Onderzoeksvraag ontvangen','Hoe komen documentkennis en het werkgeheugen samen?',['research']],
 ['working','Actieve onderzoekssessie','Vergelijk retrievalpaden en houd bronverwijzingen vast.',['sessie']],
 ['self_profile','Atlas werkprofiel','Werk lokaal en maak bronherkomst inspecteerbaar.',['profiel']],
 ['procedural','Bronnen vergelijken','Lees de bron, vergelijk claims en leg verschillen vast.',['procedure']],
 ['semantic','SQLite en geheugen','Memory nodes en edges worden via SQL opgeslagen.',['database']],
 ['semantic','Contextbudget','Frames worden binnen een geschat tokenbudget geselecteerd.',['context']],
 ['semantic','Oude databaseclaim','Een verouderde demo-claim: alle stores worden naar Postgres gespiegeld.',['conflict']],
] as const;
export const DEMO_MEMORY=specs.map(([kind,title,content,tags],i)=>({id:`demo-memory-${i+1}`,kind,title,content,tags:[...tags],provenance:{source:i===0||i===5?'document:demo-document-1':'demo-session',created_at,parent_ids:i===0?['demo-memory-2']:[],confidence:i===7?.35:.94,scope:'global',conversation_id:'demo-conversation-1'},salience:.94-i*.065,decay:.01,updated_at:created_at}));
export const DEMO_EDGES=[
 ['demo-memory-2','derived_from','demo-memory-1'],['demo-memory-1','related_to','demo-memory-6'],['demo-memory-1','related_to','demo-memory-7'],['demo-memory-8','conflicts_with','demo-memory-6'],['demo-memory-5','related_to','demo-memory-1'],['demo-document-1','has_chunk','demo-memory-1'],['demo-document-1','has_chunk','demo-memory-6']
].map(([src_id,rel,dst_id],i)=>({id:`demo-edge-${i}`,src_id,rel,dst_id,weight:.9,provenance:{source:'mock-fixture',created_at},created_at}));
export const DEMO_CHUNKS=[0,5].map((i,seq)=>({id:`demo-chunk-${seq+1}`,document_id:'demo-document-1',seq,content:DEMO_MEMORY[i].content,memory_node_id:DEMO_MEMORY[i].id,created_at}));
const hit=(i:number,head:string,score:number)=>({...DEMO_MEMORY[i],head,score,confidence:.94});
const trace=(id:string,query:string,indices:number[])=>({id,kind:'chat',conversation_id:'demo-conversation-1',model_id:'demo-local-7b',created_at,payload:{query,model_id:'demo-local-7b',embed_model:'demo-embedding',answer_chars:840,recall:{router:{semantic:.48,episodic:.17,self_profile:.06,procedural:.19,working:.10},heads:[{head:'semantic',hits:indices.map((i,n)=>hit(i,'semantic',.94-n*.08))},{head:'episodic',hits:[hit(1,'episodic',.81)]},{head:'procedural',hits:[hit(4,'procedural',.86)]},{head:'lexical',hits:[hit(indices[0],'lexical',.78)]},{head:'recency',hits:[hit(2,'recency',.72)]}],frames:[{role:'system',label:'Atlas werkprofiel',content:DEMO_MEMORY[3].content,approx_tokens:42,priority:100},{role:'system',label:'Retrieved knowledge',content:indices.map(i=>DEMO_MEMORY[i].content).join('\n'),approx_tokens:162,priority:80},{role:'system',label:'Working context',content:DEMO_MEMORY[2].content,approx_tokens:55,priority:70}],budget_tokens:2048,used_tokens:259,cut_labels:[]}}});
export function demoSnapshot():Snapshot{return {fetchedAt:created_at,baseUrl:'demo://atlas',successes:16,errors:[],engines:{db_backend:'dual',postgres:true,redis:true,objects:'local+s3'},records:{
 memory:DEMO_MEMORY,
 documents:[{id:'demo-document-1',title:'Atlas architectuurnotities',source:'demo://architecture.md',media_type:'text/markdown',object_hash:'a'.repeat(64),metadata:{demo:true},created_at,updated_at:created_at,chunk_ids:DEMO_CHUNKS.map(c=>c.id)}],
 conversations:[{id:'demo-conversation-1',title:'Het geheugen van Atlas',messages:[{role:'user',content:'Hoe koppelt Atlas documentkennis aan mijn vraag?'},{role:'assistant',content:'Via semantic memory, hybride recall en contextframes. Dit is een vooraf geschreven demoantwoord.'}],updated_at:created_at}],
 traces:[trace('demo-trace-1','Hoe koppelt Atlas documentkennis aan mijn vraag?',[0,5,6]),trace('demo-trace-2','Welke databaseclaim spreekt de bron tegen?',[5,7])],
 projects:[{id:'demo-project-1',name:'Atlas Brain Research',slug:'atlas-brain-research',description:'Voorbeeldproject om bronkennis en relaties te verkennen.',meta:{demo:true},created_at,updated_at:created_at}],
 artifacts:[{id:'demo-artifact-1',project_id:'demo-project-1',conversation_id:'demo-conversation-1',task_id:'demo-task-1',kind:'report',title:'Analyse van de geheugenlaag',object_hash:'b'.repeat(64),content:'Demo-conclusie: SQLite vormt de leesbasis; geselecteerde writes hebben een optionele Postgres-mirror.',meta:{demo:true},created_at}],
 tasks:[{id:'demo-task-1',title:'Onderzoek geheugenarchitectuur',status:'completed',conversation_id:'demo-conversation-1',plan:{steps:['Bronnen lezen','Relaties vergelijken','Rapport schrijven']},state:{completed:3,total:3,demo:true},created_at,updated_at:created_at}],
 models:[{id:'demo-local-7b',provider:'local_http',label:'Lokaal 7B · demo',meta:{demo:true,loaded:false},created_at}],
 feedback:[{id:'demo-feedback-1',trace_id:'demo-trace-2',conversation_id:'demo-conversation-1',kind:'correction',note:'Mirror-dekking verduidelijken',correction:'Postgres spiegelt geselecteerde writes, niet alle tabellen.',created_at}],
 training:[{id:'demo-training-1',source:'feedback',input:'Spiegelt Postgres alle stores?',output:'Nee, geselecteerde writes hebben een best-effort mirror.',trace_id:'demo-trace-2',meta:{conversation_id:'demo-conversation-1',demo:true},created_at}],
 costs:[{id:'demo-cost-1',trace_id:'demo-trace-1',conversation_id:'demo-conversation-1',model_id:'demo-local-7b',token_in:640,token_out:210,latency_ms:1840,cost_usd:0,created_at}],
 evalCases:[{id:'demo-eval-case-1',suite:'memory',name:'Bronherkomst behouden',query:'Hoe bewaart Atlas bronherkomst?',expect:{contains:['provenance']},tags:['demo'],created_at}],
 evalRuns:[{id:'demo-eval-run-1',suite:'memory',case_id:'demo-eval-case-1',score:1,passed:true,trace_id:'demo-trace-1',detail:{demo:true,note:'Gesimuleerde score; geen evaluatie uitgevoerd.'},created_at}],
 tools:[{name:'document.read',version:'1.0',description:'Demo-toolregistratie voor documenten; er wordt geen tool uitgevoerd.',schema:{type:'object',properties:{document_id:{type:'string'}}},policy:'ask',capabilities:['read'],enabled:true,created_at,updated_at:created_at}],
 prompts:[{id:'demo-prompt-1',name:'Atlas research',version:1,content:'Onderzoek met bronverwijzingen en benoem onzekerheden.',model_id:'demo-local-7b',active:true,created_at}]
}}}
export const DEMO_TABLES:Record<string,string>={memory_nodes:'memory',memory_embeddings:'memory',working_memory:'memory',documents:'documents',document_chunks:'chunks',memory_edges:'edges',conversations:'conversations',messages:'conversations',traces:'traces',projects:'projects',artifacts:'artifacts',tasks:'tasks',model_registry:'models',feedback:'feedback',training_examples:'training',cost_ledger:'costs',eval_cases:'evalCases',eval_runs:'evalRuns',tools:'tools',prompt_versions:'prompts'};
