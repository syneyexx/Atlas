import type { BrainEdge, BrainGraph, BrainNode, Snapshot, TraceRecord } from './types';

export const SNAPSHOT_ENDPOINTS = [
 ['memory','/memory'],['documents','/documents'],['traces','/traces?limit=50'],['projects','/projects'],['artifacts','/artifacts?limit=60'],['conversations','/conversations'],['tasks','/tasks?limit=40'],['models','/models/registry'],['feedback','/feedback?limit=40'],['training','/training?limit=40'],['costs','/costs?limit=40'],['evalCases','/evals/cases'],['evalRuns','/evals/runs?limit=40'],['tools','/tools?all=true'],['prompts','/prompts']
] as const;
export function atlasRoot(baseUrl: string): string {
 const url=new URL(baseUrl.trim());if(!['http:','https:'].includes(url.protocol))throw new Error('Gebruik een HTTP- of HTTPS-adres.');
 url.search='';url.hash='';url.pathname=url.pathname.replace(/\/$/,'').replace(/\/v1(?:\/atlas)?$/,'')+'/v1/atlas';return url.toString().replace(/\/$/,'');
}
function object(value:unknown):value is Record<string,unknown>{return value!==null&&typeof value==='object'&&!Array.isArray(value);}
function records(value:unknown):Record<string,unknown>[] {const list=Array.isArray(value)?value:object(value)&&Array.isArray(value.runs)?value.runs:[];return list.filter(object);}
async function get(root:string,path:string,signal:AbortSignal):Promise<unknown>{const r=await fetch(root+path,{signal,headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);return r.json();}
export async function fetchSnapshot(baseUrl:string,signal:AbortSignal):Promise<Snapshot>{
 const root=atlasRoot(baseUrl);const snapshot:Snapshot={fetchedAt:new Date().toISOString(),baseUrl,records:{},engines:null,errors:[],successes:0};
 const results=await Promise.allSettled([...SNAPSHOT_ENDPOINTS.map(async([name,path])=>({name,path,value:await get(root,path,signal)})),(async()=>({name:'engines',path:'/engines',value:await get(root,'/engines',signal)}))()]);
 results.forEach((result,index)=>{const endpoint=index<SNAPSHOT_ENDPOINTS.length?SNAPSHOT_ENDPOINTS[index][1]:'/engines';if(result.status==='rejected'){snapshot.errors.push({endpoint,message:result.reason instanceof Error?result.reason.message:'Ophalen mislukt'});return;}snapshot.successes++;if(result.value.name==='engines'){const v=result.value.value;if(object(v)&&typeof v.db_backend==='string')snapshot.engines={db_backend:v.db_backend,postgres:v.postgres===true,redis:v.redis===true,objects:typeof v.objects==='string'?v.objects:'onbekend'};else snapshot.errors.push({endpoint,message:'Onbekend engine-formaat'});}else snapshot.records[result.value.name]=records(result.value.value);});
 if(signal.aborted)throw new Error('Ophalen afgebroken of time-out.');
 if(!snapshot.successes)throw new Error('Atlas Brain niet bereikbaar. Controleer het adres en de toegestane frontend-origin.');
 return snapshot;
}
export async function fetchMemoryEdges(baseUrl:string,id:string,signal:AbortSignal):Promise<Record<string,unknown>[]>{const value=await get(atlasRoot(baseUrl),`/edges/${encodeURIComponent(id)}`,signal);if(!object(value))throw new Error('Onbekend edge-formaat');const all=[...(Array.isArray(value.from)?value.from:[]),...(Array.isArray(value.to)?value.to:[])].filter(object);return [...new Map(all.map(e=>[String(e.id),e])).values()];}
export async function fetchDocumentChunks(baseUrl:string,id:string,signal:AbortSignal):Promise<Record<string,unknown>[]>{const value=await get(atlasRoot(baseUrl),`/documents/${encodeURIComponent(id)}`,signal);return object(value)&&Array.isArray(value.chunks)?value.chunks.filter(object):[];}
export function getTraceRecords(snapshot:Snapshot|null):TraceRecord[]{return (snapshot?.records.traces||[]).filter((v):v is TraceRecord=>typeof v.id==='string'&&typeof v.kind==='string'&&object(v.payload));}

const COLORS_POSITION:Record<string,{x:number;y:number}>={memory:{x:690,y:410},documents:{x:270,y:500},conversations:{x:250,y:180},traces:{x:1100,y:220},projects:{x:950,y:770},artifacts:{x:1230,y:650},tasks:{x:250,y:800},models:{x:1140,y:70},feedback:{x:1320,y:430},training:{x:1450,y:750},costs:{x:1450,y:170},evalCases:{x:50,y:60},evalRuns:{x:50,y:400},tools:{x:50,y:660},prompts:{x:680,y:70}};
const categoryKind:Record<string,BrainNode['kind']>={memory:'memory',documents:'document',conversations:'conversation',traces:'trace',artifacts:'artifact',tasks:'task',models:'model'};
export function informationGraph(snapshot:Snapshot,extraEdges:Record<string,unknown>[]=[],chunks:Record<string,unknown>[]=[]):BrainGraph{
 const nodes:BrainNode[]=[];const edges:BrainEdge[]=[];const rawIds=new Map<string,string>();
 const fileMap:Record<string,string>={memory:'memory.rs',documents:'documents.rs',conversations:'conversations.rs',traces:'traces.rs',projects:'platform.rs',artifacts:'platform.rs',tasks:'tasks.rs',models:'prompts.rs',feedback:'eval.rs',training:'eval.rs',costs:'platform.rs',evalCases:'eval.rs',evalRuns:'eval.rs',tools:'tools.rs',prompts:'prompts.rs'};
 for(const [category,items]of Object.entries(snapshot.records)){
  const center=COLORS_POSITION[category]||{x:700,y:900};
  for(const [index,record]of items.slice(0,category==='memory'?80:20).entries()){
   if(nodes.length>=260)break;
   const rawId=typeof record.id==='string'?record.id:category==='tools'?`${record.name}@${record.version}`:undefined;if(!rawId)continue;
   const id=`${category}:${rawId}`;rawIds.set(rawId,id);
   const angle=index*2.39996323;const radius=items.length===1?0:Math.sqrt(index+1)*76;
   const title=category==='traces'?`Trace ${index+1}`:category==='feedback'?'Correctie: mirror-dekking':category==='training'?'Trainingsvoorbeeld':category==='costs'?'Requestkosten':category==='evalRuns'?'Evaluatieresultaat':String(record.title||record.name||record.label||record.kind||rawId.slice(0,12));
   const summary=String(record.content||record.description||record.note||record.output||record.status||'');
   nodes.push({id,rawId,label:title.length>29?title.slice(0,28)+'…':title,subtitle:category==='memory'?String(record.kind):category,kind:categoryKind[category]||'record',group:category,x:center.x+Math.cos(angle)*radius,y:center.y+Math.sin(angle)*radius,description:summary.slice(0,2500),sources:[{path:`backend/atlas-brain/src/store/${fileMap[category]||'platform.rs'}`}],record});
  }
 }
 const add=(from:string|undefined,to:string|undefined,label:string,source:string,record?:Record<string,unknown>)=>{if(!from||!to||from===to)return;const id=`${from}:${label}:${to}`;if(edges.some(e=>e.id===id))return;edges.push({id,from,to,label,kind:'relation',observed:true,sources:[{path:source}],record});};
 function referenced(raw:string):string {
  if(rawIds.has(raw))return rawIds.get(raw)!;
  const id=`reference:${raw}`;if(!nodes.some(n=>n.id===id))nodes.push({id,rawId:raw,label:raw.slice(0,12)+'…',subtitle:'Niet geladen record',kind:'reference',group:'reference',x:650+Math.cos(nodes.length)*210,y:440+Math.sin(nodes.length)*210,description:'Dit ID wordt door een geladen record genoemd. De inhoud of het type is niet in deze momentopname geladen.',sources:[]});return id;
 }
 for(const node of [...nodes]){
  const r=node.record;if(!r)continue;
  for(const field of ['project_id','conversation_id','trace_id','task_id','model_id','case_id','parent_id'])if(typeof r[field]==='string'&&r[field])add(node.id,referenced(r[field] as string),field,node.sources[0]?.path||'');
  if(object(r.provenance)){
   const p=r.provenance;if(typeof p.conversation_id==='string')add(node.id,referenced(p.conversation_id),'conversation_id',node.sources[0]?.path||'');
   if(Array.isArray(p.parent_ids))for(const parent of p.parent_ids)if(typeof parent==='string')add(referenced(parent),node.id,'derived_from','backend/atlas-brain/src/store/memory.rs');
  }
  if(typeof r.object_hash==='string'&&r.object_hash){const hash=r.object_hash;const id=`object:${hash}`;if(!nodes.some(n=>n.id===id))nodes.push({id,label:hash.slice(0,12)+'…',subtitle:'SHA256-objectreferentie',kind:'reference',group:'objects',x:350+nodes.filter(n=>n.group==='objects').length*280,y:1020,description:'Content-hash uit een document/artifact. De objectbytes zijn niet opgehaald.',sources:[{path:'backend/atlas-brain/src/store/objects.rs'}]});add(node.id,id,'object_hash','backend/atlas-brain/src/store/objects.rs');}
 }
 for(const edge of extraEdges){if(typeof edge.src_id==='string'&&typeof edge.dst_id==='string')add(referenced(edge.src_id),referenced(edge.dst_id),String(edge.rel||'relation'),'backend/atlas-brain/src/store/edges.rs',edge);}
 for(const chunk of chunks){if(typeof chunk.document_id==='string'&&typeof chunk.memory_node_id==='string')add(referenced(chunk.document_id),referenced(chunk.memory_node_id),'has_chunk','backend/atlas-brain/src/memory/ingest.rs',chunk);}
 return {nodes,edges};
}
export function traceGraph(trace:TraceRecord):BrainGraph{
 const payload=trace.payload;const recall=object(payload.recall)?payload.recall:null;const heads=recall&&Array.isArray(recall.heads)?recall.heads.filter(object):[];
 const nodes:BrainNode[]=[{id:`trace:${trace.id}`,rawId:trace.id,label:trace.kind==='chat'?'Chatrequest':'Recallrequest',subtitle:trace.created_at||trace.id.slice(0,10),kind:'trace',group:'Trace',x:150,y:410,description:String(payload.query||'Geen query in deze trace'),sources:[{path:'backend/atlas-brain/src/brain/pipeline.rs'}],record:trace}];
 const edges:BrainEdge[]=[];const root=nodes[0].id;
 const add=(from:string,to:string,label:string)=>edges.push({id:`${from}:${to}:${label}`,from,to,label,kind:'relation',observed:true,sources:[{path:'backend/atlas-brain/src/memory/cortex.rs'}]});
 for(const [index,head]of heads.entries()){
  const id=`head:${index}`;const hits=Array.isArray(head.hits)?head.hits.filter(object):[];
  nodes.push({id,label:String(head.head||'head'),subtitle:`${hits.length} hits in trace`,kind:'module',group:'Recall-heads',x:440,y:100+index*135,description:'Vastgelegde recall-head uit de trace. Dit is geen live neuronactivatie.',sources:[{path:'backend/atlas-brain/src/memory/attention.rs'}],record:head});add(root,id,'vastgelegde head');
  for(const [hi,hit]of hits.slice(0,10).entries()){
   if(typeof hit.id!=='string')continue;const mid=`hit:${hit.id}`;if(!nodes.some(n=>n.id===mid))nodes.push({id:mid,rawId:hit.id,label:String(hit.title||hit.id.slice(0,10)).slice(0,30),subtitle:`${hit.kind} · score ${typeof hit.score==='number'?hit.score.toFixed(3):'—'}`,kind:'memory',group:'Memory-hits',x:780+(hi%3)*120,y:95+index*130+(hi%2)*45,description:String(hit.content||''),sources:[{path:'backend/atlas-brain/src/memory/types.rs'}],record:hit});add(id,mid,'hit');
  }
 }
 if(recall){const frames=Array.isArray(recall.frames)?recall.frames.filter(object):[];for(const[index,frame]of frames.entries()){
  if(index>=40)break;const id=`frame:${index}`;nodes.push({id,label:`${index+1}. ${frame.label}`,subtitle:`${frame.role} · ≈${frame.approx_tokens} tokens`,kind:'record',group:'Contextframes',x:1320,y:80+index*90,description:String(frame.content||''),sources:[{path:'backend/atlas-brain/src/memory/residual.rs'}],record:frame});add(root,id,'contextframe');
 }}
 // Do not invent a hit → frame mapping: the trace has no stable frame-to-node ID.
 if(!heads.length&&!recall)nodes[0].description+='\n\nDeze trace bevat geen recall-heads/frames. Er wordt geen uitvoeringspad verzonnen.';
 return {nodes,edges};
}
