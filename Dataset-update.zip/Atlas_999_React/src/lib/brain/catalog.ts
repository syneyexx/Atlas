import type { BrainNode, BrainEdge, BrainGraph } from "./types";
export const REPOSITORY = "syneyexx/Atlas";
export const SOURCE_COMMIT = "3e25bb4e6f17157c1e4d69269282731383243e1d";
export const STORE_CATALOG = [
  {
    "name": "conversations",
    "group": "Gesprekken",
    "path": "backend/atlas-brain/src/store/db.rs",
    "line": 25,
    "fields": [
      "id TEXT PRIMARY KEY",
      "title TEXT NOT NULL",
      "messages_json TEXT NOT NULL",
      "updated_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "knowledge",
    "group": "Gesprekken",
    "path": "backend/atlas-brain/src/store/db.rs",
    "line": 31,
    "fields": [
      "id TEXT PRIMARY KEY",
      "title TEXT NOT NULL",
      "content TEXT NOT NULL",
      "tags_json TEXT NOT NULL",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "documents",
    "group": "Documenten",
    "path": "backend/atlas-brain/src/store/documents.rs",
    "line": 40,
    "fields": [
      "id TEXT PRIMARY KEY",
      "title TEXT NOT NULL",
      "source TEXT NOT NULL",
      "media_type TEXT NOT NULL",
      "object_hash TEXT NOT NULL",
      "metadata_json TEXT NOT NULL",
      "created_at TEXT NOT NULL",
      "updated_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "document_chunks",
    "group": "Documenten",
    "path": "backend/atlas-brain/src/store/documents.rs",
    "line": 53,
    "fields": [
      "id TEXT PRIMARY KEY",
      "document_id TEXT NOT NULL",
      "seq INTEGER NOT NULL",
      "content TEXT NOT NULL",
      "memory_node_id TEXT",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [
      {
        "column": "document_id",
        "target": "documents",
        "targetColumn": "id"
      }
    ],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "documents_fts",
    "group": "Documenten",
    "path": "backend/atlas-brain/src/store/documents.rs",
    "line": 64,
    "fields": [
      "document_id UNINDEXED",
      "chunk_id UNINDEXED",
      "title",
      "content"
    ],
    "foreignKeys": [],
    "fts": true,
    "postgresMirror": false
  },
  {
    "name": "eval_cases",
    "group": "Evaluatie",
    "path": "backend/atlas-brain/src/store/eval.rs",
    "line": 79,
    "fields": [
      "id TEXT PRIMARY KEY",
      "suite TEXT NOT NULL",
      "name TEXT NOT NULL",
      "query TEXT NOT NULL",
      "expect_json TEXT NOT NULL",
      "tags_json TEXT NOT NULL",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "eval_runs",
    "group": "Evaluatie",
    "path": "backend/atlas-brain/src/store/eval.rs",
    "line": 90,
    "fields": [
      "id TEXT PRIMARY KEY",
      "suite TEXT NOT NULL",
      "case_id TEXT NOT NULL",
      "score REAL NOT NULL",
      "passed INTEGER NOT NULL",
      "trace_id TEXT",
      "detail_json TEXT NOT NULL",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "feedback",
    "group": "Evaluatie",
    "path": "backend/atlas-brain/src/store/eval.rs",
    "line": 102,
    "fields": [
      "id TEXT PRIMARY KEY",
      "trace_id TEXT",
      "conversation_id TEXT",
      "kind TEXT NOT NULL",
      "note TEXT NOT NULL",
      "correction TEXT",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "training_examples",
    "group": "Evaluatie",
    "path": "backend/atlas-brain/src/store/eval.rs",
    "line": 113,
    "fields": [
      "id TEXT PRIMARY KEY",
      "source TEXT NOT NULL",
      "input TEXT NOT NULL",
      "output TEXT NOT NULL",
      "trace_id TEXT",
      "meta_json TEXT NOT NULL",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "semantic_cache",
    "group": "Evaluatie",
    "path": "backend/atlas-brain/src/store/eval.rs",
    "line": 123,
    "fields": [
      "cache_key TEXT PRIMARY KEY",
      "response TEXT NOT NULL",
      "model_id TEXT NOT NULL",
      "hit_count INTEGER NOT NULL DEFAULT 0",
      "created_at TEXT NOT NULL",
      "updated_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "memory_nodes",
    "group": "Geheugen",
    "path": "backend/atlas-brain/src/store/memory.rs",
    "line": 17,
    "fields": [
      "id TEXT PRIMARY KEY",
      "kind TEXT NOT NULL",
      "title TEXT NOT NULL",
      "content TEXT NOT NULL",
      "tags_json TEXT NOT NULL",
      "source TEXT NOT NULL",
      "created_at TEXT NOT NULL",
      "parent_ids_json TEXT NOT NULL",
      "confidence REAL NOT NULL",
      "scope TEXT NOT NULL",
      "conversation_id TEXT",
      "salience REAL NOT NULL",
      "decay REAL NOT NULL",
      "archived_at TEXT",
      "updated_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "memory_embeddings",
    "group": "Geheugen",
    "path": "backend/atlas-brain/src/store/memory.rs",
    "line": 34,
    "fields": [
      "node_id TEXT PRIMARY KEY",
      "dim INTEGER NOT NULL",
      "vector_json BLOB NOT NULL"
    ],
    "foreignKeys": [
      {
        "column": "node_id",
        "target": "memory_nodes",
        "targetColumn": "id"
      }
    ],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "working_memory",
    "group": "Geheugen",
    "path": "backend/atlas-brain/src/store/memory.rs",
    "line": 42,
    "fields": [
      "conversation_id TEXT PRIMARY KEY",
      "state_json TEXT NOT NULL",
      "query_embedding BLOB",
      "updated_at TEXT NOT NULL",
      "expires_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "messages",
    "group": "Relaties & traces",
    "path": "backend/atlas-brain/src/store/plane.rs",
    "line": 15,
    "fields": [
      "id TEXT PRIMARY KEY",
      "conversation_id TEXT NOT NULL",
      "seq INTEGER NOT NULL",
      "role TEXT NOT NULL",
      "content TEXT NOT NULL",
      "callout_json TEXT",
      "created_at TEXT",
      "trace_id TEXT",
      "model_id TEXT"
    ],
    "foreignKeys": [
      {
        "column": "conversation_id",
        "target": "conversations",
        "targetColumn": "id"
      }
    ],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "memory_edges",
    "group": "Relaties & traces",
    "path": "backend/atlas-brain/src/store/plane.rs",
    "line": 30,
    "fields": [
      "id TEXT PRIMARY KEY",
      "src_id TEXT NOT NULL",
      "rel TEXT NOT NULL",
      "dst_id TEXT NOT NULL",
      "weight REAL NOT NULL DEFAULT 1.0",
      "provenance_json TEXT NOT NULL",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "traces",
    "group": "Relaties & traces",
    "path": "backend/atlas-brain/src/store/plane.rs",
    "line": 43,
    "fields": [
      "id TEXT PRIMARY KEY",
      "kind TEXT NOT NULL",
      "conversation_id TEXT",
      "model_id TEXT",
      "payload_json TEXT NOT NULL",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "outbox",
    "group": "Relaties & traces",
    "path": "backend/atlas-brain/src/store/plane.rs",
    "line": 54,
    "fields": [
      "id TEXT PRIMARY KEY",
      "event_type TEXT NOT NULL",
      "payload_json TEXT NOT NULL",
      "created_at TEXT NOT NULL",
      "processed_at TEXT"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "messages_fts",
    "group": "Relaties & traces",
    "path": "backend/atlas-brain/src/store/plane.rs",
    "line": 77,
    "fields": [
      "message_id UNINDEXED",
      "conversation_id UNINDEXED",
      "role UNINDEXED",
      "body"
    ],
    "foreignKeys": [],
    "fts": true,
    "postgresMirror": false
  },
  {
    "name": "memory_fts",
    "group": "Relaties & traces",
    "path": "backend/atlas-brain/src/store/plane.rs",
    "line": 84,
    "fields": [
      "node_id UNINDEXED",
      "kind UNINDEXED",
      "title",
      "content",
      "tags"
    ],
    "foreignKeys": [],
    "fts": true,
    "postgresMirror": false
  },
  {
    "name": "projects",
    "group": "Platform",
    "path": "backend/atlas-brain/src/store/platform.rs",
    "line": 90,
    "fields": [
      "id TEXT PRIMARY KEY",
      "name TEXT NOT NULL",
      "slug TEXT NOT NULL UNIQUE",
      "description TEXT NOT NULL DEFAULT ''",
      "meta_json TEXT NOT NULL DEFAULT '{}'",
      "created_at TEXT NOT NULL",
      "updated_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "artifacts",
    "group": "Platform",
    "path": "backend/atlas-brain/src/store/platform.rs",
    "line": 99,
    "fields": [
      "id TEXT PRIMARY KEY",
      "project_id TEXT",
      "conversation_id TEXT",
      "task_id TEXT",
      "kind TEXT NOT NULL",
      "title TEXT NOT NULL",
      "object_hash TEXT",
      "content TEXT",
      "meta_json TEXT NOT NULL DEFAULT '{}'",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "cost_ledger",
    "group": "Platform",
    "path": "backend/atlas-brain/src/store/platform.rs",
    "line": 112,
    "fields": [
      "id TEXT PRIMARY KEY",
      "trace_id TEXT",
      "conversation_id TEXT",
      "model_id TEXT",
      "token_in INTEGER NOT NULL DEFAULT 0",
      "token_out INTEGER NOT NULL DEFAULT 0",
      "latency_ms INTEGER NOT NULL DEFAULT 0",
      "cost_usd REAL NOT NULL DEFAULT 0",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "secrets",
    "group": "Platform",
    "path": "backend/atlas-brain/src/store/platform.rs",
    "line": 124,
    "fields": [
      "id TEXT PRIMARY KEY",
      "name TEXT NOT NULL UNIQUE",
      "ciphertext TEXT NOT NULL",
      "nonce TEXT NOT NULL",
      "created_at TEXT NOT NULL",
      "updated_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": true
  },
  {
    "name": "code_files",
    "group": "Platform",
    "path": "backend/atlas-brain/src/store/platform.rs",
    "line": 132,
    "fields": [
      "id TEXT PRIMARY KEY",
      "project_id TEXT",
      "path TEXT NOT NULL",
      "language TEXT NOT NULL DEFAULT ''",
      "content_hash TEXT NOT NULL",
      "size_bytes INTEGER NOT NULL DEFAULT 0",
      "updated_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "code_symbols",
    "group": "Platform",
    "path": "backend/atlas-brain/src/store/platform.rs",
    "line": 142,
    "fields": [
      "id TEXT PRIMARY KEY",
      "file_id TEXT NOT NULL",
      "name TEXT NOT NULL",
      "kind TEXT NOT NULL",
      "line_start INTEGER NOT NULL",
      "line_end INTEGER NOT NULL",
      "signature TEXT NOT NULL DEFAULT ''"
    ],
    "foreignKeys": [
      {
        "column": "file_id",
        "target": "code_files",
        "targetColumn": "id"
      }
    ],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "code_symbols_fts",
    "group": "Platform",
    "path": "backend/atlas-brain/src/store/platform.rs",
    "line": 153,
    "fields": [
      "symbol_id UNINDEXED",
      "name",
      "signature",
      "path UNINDEXED"
    ],
    "foreignKeys": [],
    "fts": true,
    "postgresMirror": false
  },
  {
    "name": "tools",
    "group": "Agent OS",
    "path": "backend/atlas-brain/src/store/tools.rs",
    "line": 29,
    "fields": [
      "name TEXT NOT NULL",
      "version TEXT NOT NULL",
      "description TEXT NOT NULL",
      "schema_json TEXT NOT NULL",
      "policy TEXT NOT NULL",
      "capabilities_json TEXT NOT NULL",
      "enabled INTEGER NOT NULL DEFAULT 1",
      "created_at TEXT NOT NULL",
      "updated_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "tasks",
    "group": "Agent OS",
    "path": "backend/atlas-brain/src/store/tools.rs",
    "line": 43,
    "fields": [
      "id TEXT PRIMARY KEY",
      "title TEXT NOT NULL",
      "status TEXT NOT NULL",
      "conversation_id TEXT",
      "parent_id TEXT",
      "plan_json TEXT NOT NULL",
      "state_json TEXT NOT NULL",
      "created_at TEXT NOT NULL",
      "updated_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "task_checkpoints",
    "group": "Agent OS",
    "path": "backend/atlas-brain/src/store/tools.rs",
    "line": 56,
    "fields": [
      "id TEXT PRIMARY KEY",
      "task_id TEXT NOT NULL",
      "label TEXT NOT NULL",
      "snapshot_json TEXT NOT NULL",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [
      {
        "column": "task_id",
        "target": "tasks",
        "targetColumn": "id"
      }
    ],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "prompt_versions",
    "group": "Agent OS",
    "path": "backend/atlas-brain/src/store/tools.rs",
    "line": 66,
    "fields": [
      "id TEXT PRIMARY KEY",
      "name TEXT NOT NULL",
      "version INTEGER NOT NULL",
      "content TEXT NOT NULL",
      "model_id TEXT",
      "active INTEGER NOT NULL DEFAULT 0",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  },
  {
    "name": "model_registry",
    "group": "Agent OS",
    "path": "backend/atlas-brain/src/store/tools.rs",
    "line": 78,
    "fields": [
      "id TEXT PRIMARY KEY",
      "provider TEXT NOT NULL",
      "label TEXT NOT NULL",
      "meta_json TEXT NOT NULL",
      "created_at TEXT NOT NULL"
    ],
    "foreignKeys": [],
    "fts": false,
    "postgresMirror": false
  }
] as const;

const src = (file: string, note?: string) => [{path: `backend/atlas-brain/src/${file}`, note}];
const moduleNode = (id: string,label: string,subtitle: string,group: string,x: number,y: number,description: string,file: string,kind: BrainNode['kind']='module',tables?: string[],conditional=false): BrainNode => ({id,label,subtitle,group,x,y,description,sources:src(file),kind,tables,conditional});
export const ARCHITECTURE_NODES: BrainNode[] = [
  moduleNode('interface','Atlas UI','React · Vite','Interface',100,310,'De frontend stuurt gesprekken naar Atlas Brain en beheert de zichtbare werkruimtes. LocalStorage is een lokale cache.','api/mod.rs'),
  moduleNode('api','Brain API','Axum · request-driven','Interface',290,310,'Rust HTTP-entrypoint. Elke request activeert de benodigde pipeline; er is geen continu denkende achtergrondlus.','api/mod.rs','core'),
  moduleNode('cache','Response cache','Optioneel · exacte sleutel','Geheugen',105,110,'Vroeg pad in chat.rs: cache bij ingeschakelde instelling. De sleutel is een SHA256 van model, prompt en usertekst, geen vectorzoekactie. Een hit keert vóór de Cortex-pipeline terug.','api/chat.rs','store',['semantic_cache'],true),
  moduleNode('working','Working memory','Conversatie · TTL','Geheugen',475,500,'Laadt sessietoestand via Redis indien geconfigureerd, anders SQLite. TTL-controle vindt on-read plaats. Save gebeurt in de Cortex vóór de LM-aanroep.','memory/working.rs','store',['working_memory']),
  moduleNode('router','Expert router','Heuristische MoE-mix','Geheugen',455,220,'Keyword-priors plus continuïteit uit working memory, daarna normalisatie. Dit zijn codeheuristieken; geen nieuw getraind neuraal model. Vijf expertgewichten bepalen mede de headcapaciteit.','memory/moe.rs'),
  moduleNode('attention','Multi-head recall','Vector · FTS · recency','Geheugen',680,140,'Semantic, episodic, self_profile, procedural, lexical en recency. Cosine over embeddings wordt gecombineerd met lexical/BM25 en salience. Een working-head kan worden toegevoegd.','memory/attention.rs'),
  moduleNode('cortex','MEMORY CORTEX','Atlas Brain · één geheugenlaag','Geheugen',665,355,'Verbindt working memory, router, recall-heads, fusion, contextframes en terugschrijven van salience. Een extra graph-hop is configureerbaar.','memory/cortex.rs','core'),
  moduleNode('fusion','Fusion & graph-hop','Gating · optionele hop 2','Geheugen',875,240,'Fuseert hits per node-ID. Bij memory_hops > 1 worden edge-neighbors gevolgd en wordt opnieuw gezocht met uitgebreidere querytekst.','memory/cortex.rs'),
  moduleNode('context','ContextStream','Frames · tokenbudget','Geheugen',925,430,'Maakt system-, profiel-, semantic-, procedural-, episodic-, working- en conversatieframes. De tokenraming is chars/4. Dit is contextinjectie, geen gewichtsupdate.','memory/residual.rs'),
  moduleNode('lm','Local LLM','local_http of stub','Model',1180,430,'LocalLmClient verstuurt de samengestelde berichten naar de geconfigureerde completion-API. De modelgewichten worden in deze pipeline niet getraind.','lm/client.rs','model'),
  moduleNode('embed','Embedding client','local_http / local_hash','Model',455,70,'Query- en geheugenembeddings. Offline stub/local_hash gebruikt een deterministische hashvector; local_http roept een embeddingmodel aan.','memory/embed.rs','model'),
  moduleNode('salience','Salience update','Bump · soften','Geheugen',685,550,'Verhoogt salience van fused hits en verzacht near-miss candidates. Deze updates vinden plaats tijdens recall, vóór LM-completion.','memory/cortex.rs'),
  moduleNode('governor','Write Governor','Insert · merge · conflict','Ingest',275,535,'Controleert tekst, chunking, embeddings en bestaande nodes. Kan dedupen, samenvoegen of conflicts_with vastleggen. Chat-episoden worden na het antwoord geschreven.','memory/write.rs'),
  moduleNode('ingest','Document ingest','Object → chunks → memory','Ingest',80,675,'Legt het tekstobject vast, maakt document/chunkrecords en semantic memory via WriteGovernor. has_chunk koppelt document-ID aan memory-node-ID; chunk-ID staat in provenance.','memory/ingest.rs'),
  moduleNode('documents','Document store','Chunks & bronherkomst','Ingest',275,705,'Documentmetadata en chunkteksten met optionele memory_node_id; FTS5 voor documentzoekactie.','store/documents.rs','store',['documents','document_chunks','documents_fts']),
  moduleNode('memories','Memory nodes','5 soorten · provenance','Geheugen',660,685,'Episodic, semantic, procedural, self_profile en working delen memory_nodes. Een soort is geen aparte fysieke database.','store/memory.rs','store',['memory_nodes','memory_embeddings','memory_fts','knowledge']),
  moduleNode('edges','Memory graph','SQL-relaties · gewichten','Geheugen',900,665,'Gedeelde memory_edges: src_id, rel, dst_id, weight en provenance. Dit is de bestaande graph-engine; er is geen Neo4j-pad in de code.','store/edges.rs','store',['memory_edges']),
  moduleNode('consolidate','Consolidatie','Episode → duurzame kennis','Ingest',455,665,'On-demand distillatie via dezelfde LM of stub. Nieuwe semantic nodes krijgen source_ids als parent_ids. Geen achtergrondtrainer.','memory/consolidate.rs'),
  moduleNode('conversations','Gesprekken','Messages · trace_id','Platform',1270,160,'Genormaliseerde messages zijn de primaire dialoogrijen; messages_json blijft een compatibiliteitskopie. Geen Postgres-mirror-write gevonden in replace_messages.','store/conversations.rs','store',['conversations','messages','messages_fts']),
  moduleNode('traces','Trace store','Hits · router · frames','Platform',1250,590,'Pipeline slaat een trace met query, hit_ids, recall en modelmetadata op. Trace is inspectie achteraf, geen live stream van interne activaties.','store/traces.rs','store',['traces','cost_ledger']),
  moduleNode('agent','Agent OS','Registry · taken · prompts','Platform',1430,320,'Tools, policy en capabilities, taken met checkpoints, promptversies en modelregistry. Een toolregistratie bewijst niet dat een autonoom uitvoeringspad bestaat.','api/agent_api.rs','store',['tools','tasks','task_checkpoints','prompt_versions','model_registry']),
  moduleNode('improve','Verbeterlus','Evals · feedback · voorbeelden','Platform',1445,590,'Evals zijn expliciete requests. Feedbackcorrecties kunnen training_examples opleveren; het opslaan daarvan voert geen training uit.','api/eval_api.rs','store',['eval_cases','eval_runs','feedback','training_examples']),
  moduleNode('projects','Project & artifacts','Scope · object_hash','Platform',1275,780,'Projecten, artifacts, codebestanden en symbolen dragen IDs en optionele scopeverwijzingen. Secrets zijn versleutelde opslag, geen grafisch uit te lezen inhoud.','store/platform.rs','store',['projects','artifacts','code_files','code_symbols','code_symbols_fts','secrets']),
  moduleNode('outbox','Outbox','Durable acknowledgements','Opslag',1090,900,'De huidige drain markeert events processed. Er wordt in drain_outbox geen externe consumer of echte eventverwerking uitgevoerd.','store/outbox.rs','store',['outbox']),
  moduleNode('sqlite','SQLite','atlas.db · actieve leesengine','Opslag',660,900,'Store::open opent altijd SQLite met WAL en foreign_keys. Ook bij de postgres-modus blijven de requestqueries op dit SQLite-pad.','store/db.rs','engine'),
  moduleNode('postgres','Postgres mirror','Configureerbaar · best effort','Opslag',875,1040,'Geselecteerde writes worden gespiegeld. Mirrorfouten worden vaak als waarschuwing gelogd. Schema-aanwezigheid betekent niet dat elke tabel al wordt gespiegeld.','store/engines/pg_mirror.rs','engine',undefined,true),
  moduleNode('redis','Redis hot path','Working KV · response cache','Opslag',1230,990,'Optionele snelle laag met TTL. Working/cache hebben tevens SQLite-opslag. Engine status meldt geconfigureerde handles, geen actuele gezondheidstest.','store/engines/redis_hot.rs','engine',undefined,true),
  moduleNode('objects','Object storage','SHA256 · lokale bytes','Opslag',275,910,'Content-addressed objecten in data/objects. Documenten en artifacts refereren aan object_hash.','store/objects.rs','engine'),
  moduleNode('s3','S3 / MinIO','Optioneel · lokale mirror','Opslag',85,1035,'S3-modus bewaart eerst een lokale mirror en schrijft daarna naar de objectdienst. Reads proberen lokale bytes vóór S3.','store/engines/object_s3.rs','engine',undefined,true),
  moduleNode('settings','Config plane','brain-config.json','Interface',80,490,'Instellingen voor model, prompts, tokenbudget en geheugen. Settings API activeert promptversionering en modelregistry-sync.','api/config_api.rs','store'),
];
function edge(from: string,to: string,label: string,file: string,kind: BrainEdge['kind']='flow'): BrainEdge {return {id:`${from}:${to}:${label}`,from,to,label,kind,sources:src(file)};}
export const ARCHITECTURE_EDGES: BrainEdge[] = [
  edge('interface','api','HTTP','api/mod.rs'),edge('api','cache','cache lookup','api/chat.rs','conditional'),edge('cache','interface','cache hit','api/chat.rs','conditional'),
  edge('api','cortex','run_completion','brain/pipeline.rs'),edge('settings','context','system_prompt','memory/residual.rs','read'),edge('working','router','continuïteit','memory/cortex.rs','read'),edge('router','attention','expertgewichten','memory/attention.rs'),edge('cortex','router','route_experts','memory/cortex.rs'),edge('embed','attention','queryvector','memory/attention.rs'),edge('memories','attention','nodes & embeddings','memory/attention.rs','read'),edge('attention','fusion','head hits','memory/cortex.rs'),edge('edges','fusion','neighbor_ids','memory/cortex.rs','conditional'),edge('fusion','context','geselecteerde hits','memory/cortex.rs'),edge('cortex','working','save_working','memory/cortex.rs','write'),edge('fusion','salience','gebruikte hits','memory/cortex.rs'),edge('salience','memories','upsert salience','memory/cortex.rs','write'),edge('context','lm','samengestelde berichten','brain/pipeline.rs'),edge('lm','traces','antwoord & metadata','brain/pipeline.rs','write'),edge('lm','conversations','persist=true','api/chat.rs','write'),edge('api','governor','laatste userturn na LM','api/chat.rs','conditional'),edge('ingest','governor','semantic chunks','memory/ingest.rs'),edge('ingest','documents','metadata & chunks','memory/ingest.rs','write'),edge('ingest','objects','objectbytes','memory/ingest.rs','write'),edge('governor','embed','embed tekst','memory/write.rs'),edge('governor','memories','commit','memory/write.rs','write'),edge('governor','edges','conflicts_with','memory/write.rs','conditional'),edge('governor','outbox','memory event','memory/write.rs','write'),edge('memories','consolidate','episodische bronnen','memory/consolidate.rs','read'),edge('consolidate','lm','distillatie','memory/consolidate.rs','conditional'),edge('consolidate','governor','nieuwe semantic memory','memory/consolidate.rs','write'),edge('documents','edges','has_chunk','memory/ingest.rs','write'),edge('memories','sqlite','SQL + FTS','store/memory.rs','write'),edge('working','sqlite','duurzame sessiekopie','store/memory.rs','write'),edge('documents','sqlite','documentrecords','store/documents.rs','write'),edge('edges','sqlite','SQL graph','store/edges.rs','write'),edge('traces','sqlite','trace & kosten','store/traces.rs','write'),edge('conversations','sqlite','messages + FTS','store/conversations.rs','write'),edge('agent','sqlite','registry & taken','store/tools.rs','write'),edge('improve','sqlite','evals & feedback','store/eval.rs','write'),edge('projects','sqlite','platformrecords','store/platform.rs','write'),edge('outbox','sqlite','pending / processed','store/outbox.rs','write'),edge('sqlite','postgres','geselecteerde mirrors','store/engines/pg_mirror.rs','mirror'),edge('working','redis','hot copy','store/memory.rs','conditional'),edge('cache','redis','hot cache','store/eval.rs','conditional'),edge('cache','sqlite','duurzame cache','store/eval.rs','write'),edge('objects','s3','S3 + lokale mirror','store/engines/object_s3.rs','mirror'),edge('projects','objects','artifact bytes','api/platform_api.rs','write'),edge('traces','improve','trace_id','api/eval_api.rs','relation')
];
export const ARCHITECTURE_GRAPH: BrainGraph = {nodes:ARCHITECTURE_NODES,edges:ARCHITECTURE_EDGES};

export function storageGraph(): BrainGraph {
  const names = [...new Set(STORE_CATALOG.map(t=>t.group))];
  const nodes: BrainNode[] = STORE_CATALOG.map((table,index)=>{
    const groupIndex=names.indexOf(table.group);const siblings=STORE_CATALOG.filter(t=>t.group===table.group);const row=siblings.findIndex(t=>t.name===table.name);
    return {id:`table:${table.name}`,label:table.name,subtitle:table.fts?'FTS5 · virtuele tabel':'SQLite · tabel',kind:'store',group:table.group,x:130+(groupIndex%4)*355+(row%2)*155,y:130+Math.floor(groupIndex/4)*540+Math.floor(row/2)*110,description:`Gedefinieerd in ${table.path}. ${table.postgresMirror?'Een expliciet Postgres-mirrorpad is aangetroffen.':'Geen expliciet Postgres-mirrorpad voor deze tabel aangetroffen.'}`,sources:[{path:table.path,line:table.line}],tables:[table.name],fields:[...table.fields]};
  });
  const edges: BrainEdge[]=[];
  for(const table of STORE_CATALOG)for(const fk of table.foreignKeys)edges.push({id:`fk:${table.name}:${fk.column}`,from:`table:${table.name}`,to:`table:${fk.target}`,label:`FK ${fk.column}`,kind:'relation',sources:[{path:table.path,line:table.line}]});
  const logical:[string,string,string,string][]=[['memory_nodes','memory_embeddings','node_id','store/memory.rs'],['memory_nodes','memory_edges','src_id / dst_id','store/edges.rs'],['memory_nodes','working_memory','conversation_id','memory/cortex.rs'],['documents','memory_nodes','has_chunk','memory/ingest.rs'],['messages','traces','trace_id','store/conversations.rs'],['traces','cost_ledger','trace_id','api/chat.rs'],['feedback','training_examples','correctie → voorbeeld','api/eval_api.rs'],['eval_runs','traces','trace_id','memory/eval_runner.rs'],['artifacts','projects','project_id','store/platform.rs'],['artifacts','tasks','task_id','store/platform.rs'],['tasks','conversations','conversation_id','store/tasks.rs'],['prompt_versions','model_registry','model_id','store/prompts.rs']];
  for(const [from,to,label,file]of logical)edges.push({id:`logical:${from}:${to}`,from:`table:${from}`,to:`table:${to}`,label,kind:'conditional',sources:src(file)});
  return {nodes,edges};
}
export const FLOW_STEPS = [
  {title:'Inkomende vraag',description:'Chatrequest en eventuele exacte responsecache. Bij een cachehit wordt de Cortex overgeslagen.',nodes:['interface','api','cache'],file:'api/chat.rs'},
  {title:'Werkgeheugen & router',description:'Working KV levert sessiecontinuïteit. De heuristische router normaliseert vijf expertgewichten.',nodes:['api','cortex','working','router','redis'],file:'memory/cortex.rs'},
  {title:'Hybrid recall',description:'Embedding, cosine, FTS/BM25, recency en salience leveren gerangschikte head-hits.',nodes:['router','attention','embed','memories','sqlite'],file:'memory/attention.rs'},
  {title:'Fusion & optionele hop',description:'Hits worden samengevoegd; memory_hops > 1 kan neighbors via memory_edges meenemen.',nodes:['attention','fusion','edges','memories'],file:'memory/cortex.rs'},
  {title:'Context samenstellen',description:'Contextframes worden geordend en binnen het geschatte tokenbudget geselecteerd.',nodes:['fusion','context','settings'],file:'memory/residual.rs'},
  {title:'Recall terugschrijven',description:'Salience en working memory worden al tijdens recall bijgewerkt, vóór de LM-completion.',nodes:['fusion','salience','memories','working','sqlite'],file:'memory/cortex.rs'},
  {title:'Lokale LM-completion',description:'De samengestelde context gaat naar LocalLmClient; er worden geen modelgewichten getraind.',nodes:['context','lm'],file:'brain/pipeline.rs'},
  {title:'Trace & gesprek bewaren',description:'Trace, kosten, eventuele cache en conversation/messages worden na de LM-call vastgelegd.',nodes:['lm','traces','conversations','cache','sqlite'],file:'api/chat.rs'},
  {title:'Episodisch leren',description:'Indien ingesteld schrijft WriteGovernor de laatste userturn als episode. Consolidatie is optioneel.',nodes:['api','governor','embed','memories','consolidate','outbox'],file:'api/chat.rs'},
  {title:'Outbox acknowledgement',description:'De huidige drain markeert events als processed; dit is geen externe workflowconsumer.',nodes:['outbox','sqlite','postgres'],file:'store/outbox.rs'}
];
