export type ResearchEvent = { id: string; timestamp: string; type: 'QUEUE' | 'SEARCH' | 'FETCH' | 'PARSE' | 'EXEC' | 'WRITE' | 'WAIT' | 'PAUSE'; lines: string[]; details?: string };
export type ResearchTask = { id: string; title: string; mode: string; example?: boolean; paused?: boolean; events: ResearchEvent[]; attachment?: {name: string; type: string; size: number} };
export const exampleResearch: ResearchTask = {id:'research-example', title:'Hoe bouw je een betrouwbaar lokaal AI-framework?', mode:'Verdiepend', example:true, events:[
  {id:'e1',timestamp:'14:28:03',type:'QUEUE',lines:['research.local_ai · taak gestart']},
  {id:'e2',timestamp:'14:28:04',type:'SEARCH',lines:['query: local LLM tool calling','limiet: 5 bronnen']},
  {id:'e3',timestamp:'14:28:06',type:'FETCH',lines:['bron: docs.djl.ai','status: 200 · 18.4 kB']},
  {id:'e4',timestamp:'14:28:08',type:'PARSE',lines:['3 relevante passages gevonden']},
  {id:'e5',timestamp:'14:28:10',type:'EXEC',lines:['python verify_claims.py','exit: 0 · 2 checks geslaagd'],details:'VOORBEELD — niet uitgevoerd.\n\nCommando: python verify_claims.py\nWerkmap: research/local-ai\nExitcode: 0\nStandaarduitvoer: 2 checks geslaagd\nStandaardfouten: geen\n\nEen toekomstige onderzoeksbackend levert hier echte argumenten, stdout, stderr en exitcodes.'},
  {id:'e6',timestamp:'14:28:12',type:'WRITE',lines:['research/local-ai/notities.md']},
  {id:'e7',timestamp:'14:28:13',type:'WAIT',lines:['Volgende bron in wachtrij']},
]};
export function researchTime() {return new Intl.DateTimeFormat('nl-NL',{hour:'2-digit',minute:'2-digit',second:'2-digit',timeZone:'Europe/Amsterdam'}).format(new Date());}
/** Accept events from a future backend here. Never invent EXEC/FETCH events on the client. */
export function isResearchTask(value: unknown): value is ResearchTask {
  if (!value || typeof value !== 'object') return false;
  const item = value as ResearchTask;
  return typeof item.id === 'string' && typeof item.title === 'string' && typeof item.mode === 'string' && Array.isArray(item.events) && item.events.every(event=>event && typeof event.id === 'string' && typeof event.timestamp === 'string' && ['QUEUE','SEARCH','FETCH','PARSE','EXEC','WRITE','WAIT','PAUSE'].includes(event.type) && Array.isArray(event.lines) && event.lines.every(line=>typeof line === 'string'));
}
