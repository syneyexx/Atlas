# Brain Graphics — Atlas 999

Geïntegreerd in Data → Brain Graphics; Chat en Research blijven beschikbaar. Desktop-interface.

## Gebruik
`npm install` en `npm run dev`. Open de lokale URL, kies Data en Brain Graphics. Direct openen: /#brain. Productie: `npm run build`, daarna `npm run preview`.

Architectuur: 30 modules en engines, klikbare relaties, bronlinks, zoeken, focus, slepen, zoom en tien uitlegstappen. Opslag: 31 SQLite-schemaobjecten (27 tabellen en 4 FTS5-tabellen); foreign keys en aparte codeverwijzingen. Informatie en Request trace vereisen een handmatige snapshot van een actieve Atlas Brain API. Stel het API-adres rechts in. De pagina voert uitsluitend GET-verzoeken uit; geen polling of writes. Een snapshot kan gedeeltelijk zijn en toont endpointfouten. Gegevens blijven in de browsersessie en worden niet automatisch opgeslagen. De API moet bereikbaar zijn vanuit de browser en passende CORS toestaan. Relaties van memory nodes en documentchunks worden op verzoek geladen. De informatiekaart begrenst het aantal zichtbare records; dit is geen volledige database-export.

## Bron en grenzen
Read-only analyse van syneyexx/Atlas op commit 3e25bb4e6f17157c1e4d69269282731383243e1d. Geen GitHub-wijzigingen. Codeverwijzingen staan in src/lib/brain/catalog.ts.

SQLite blijft de actieve leesengine. Postgres is een optionele best-effort mirror voor geselecteerde writes. Redis dient working memory en responsecache; S3/MinIO is optioneel naast lokale objectopslag. De graph gebruikt memory_edges in SQL. Memorysoorten delen memory_nodes. De expert-router is heuristisch, niet een getrainde neural layer. De uitlegmodus toont codevolgorde en geen live activaties of interne modelgedachten. Een trace toont opgeslagen recall-hits en contextframes; er worden geen hit-naar-frame relaties verzonnen. Feedback levert trainingsvoorbeelden op en traint in dit pad geen modelgewichten. De huidige outbox-drain bevestigt events zonder externe workflowdispatch. Tools en tasks zijn registries; automatische tooluitvoering is niet verondersteld.

## Controle
TypeScript en Vite-productiebuild geslaagd. Browsercontrole: Data/submenu, Research terugnavigeren, opslagkaart en node-inspector, zoom/reset en requeststappen. Geen actieve Brain API beschikbaar voor een end-to-end snapshotcontrole. Dit pakket bevat de frontend en vereist een aparte backend voor runtimefuncties.
