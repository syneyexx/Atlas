# Datasets — Atlas 999 0.5.0

Onder Data → Datasets. Rechtstreeks via /#datasets. Desktop-layout op basis van de goedgekeurde afbeelding public/assets/datasets-design-specification.png. De drie rechter widgets zijn vervangen door één importconsole. Alle eerdere pagina’s blijven behouden.

## Werkende demo
- Bibliotheek met vier fictieve datasets; statistieken berekend uit de huidige records en voortgang.
- Zoeken op naam/repository, typefilter, collecties, downloadfilter, opslagoverzicht en lijst/raster.
- Klik op een dataset voor metadata en fictieve voorbeeldrecords. Actiemenu voor details, actuele console en verwijderen uit de demo.
- Repository-ID of Hugging Face dataset-URL invullen, configuratie/split/formaat selecteren, voorbeeldmetadata bekijken en demo-import starten. Er kan één import tegelijk actief zijn.
- Initiële Research Corpus-demo begint bij 68% wanneer je Datasets voor het eerst opent. Voortgang, gesimuleerde bestandscontroles, manifest en registratie verschijnen in de console. Pauzeren, hervatten en annuleren veranderen de toestand en logregels. Bij voltooiing wordt de status Gereed.
- Console vergroten, autoscroll schakelen, log kopiëren of als tekst downloaden.
- Navigeren naar andere pagina’s bewaart de datasetsessie en laat een actieve simulatie verdergaan. Vernieuwen van de browser reset deze demo.

## Geen echte download
Dit is de aangevraagde interactieve frontend met mockdata. De Hugging Face-velden leiden niet tot netwerkverzoeken. Er wordt geen dataset of checksum werkelijk opgehaald, geverifieerd of naar schijf geschreven. Alle voorbeeldmetadata is fictief, ook wanneer een bestaande repository-ID wordt ingevoerd. Alleen de expliciete knop Log downloaden maakt een echt tekstbestand via je browser.

## Code
`src/components/datasets/DatasetsWorkspace.tsx`: pagina, dialogen en simulatie.
`src/lib/datasets.ts`: types, fixtures, repository-parser, opmaak en log-events.
`public/assets/datasets.css`: eigen desktop-stijlen.
`AtlasWorkspace.tsx`: Data-submenu, bibliotheeksidebar en sessiebehoud.

Voor een echte integratie moet de simulator worden vervangen door een backendadapter die metadata en downloadjobs levert. Ondersteuning voor gated datasets, credentials, revisions, streaming, retries, echte lokale opslag en integriteitscontrole zijn niet in dit frontendpakket geïmplementeerd. Toon alleen backend-bevestigde gebeurtenissen als echte console-events. De bestaande Brain API-snapshotfunctie blijft los hiervan beschikbaar.

## Starten
Installeer Node.js 22.13+ (of nieuwer compatibel), open deze map in een terminal en voer `npm install` en `npm run dev` uit. Open de getoonde localhost-URL en kies Data → Datasets. Productiebouw: `npm run build`; bekijken: `npm run preview`. Open dist/index.html niet rechtstreeks via file://.
