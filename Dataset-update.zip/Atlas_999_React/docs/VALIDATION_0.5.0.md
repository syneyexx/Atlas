# Controle 0.5.0

TypeScript typecheck en Vite-productiebuild geslaagd. Desktop-browsercontrole uitgevoerd op de geïntegreerde Atlas-layout:
- Data actief en submenu Datasets bereikbaar via /#datasets.
- Pauzeren/hervatten/annuleren verschijnen als console-events en stoppen/hervatten de simulator.
- Nieuwe repository-URL → voorbeeldmetadata → nieuwe demo-import.
- Zoeken op datasetnaam, lijst/raster, details met voorbeeldrecords, vergrote console en kopiëren.
- Download van tekstlog als browserbestand gelukt.
- Initiële demo loopt door naar controle, registratie en Gereed; Downloads-teller wordt 0.
- Terugnavigatie naar Research, Brain Graphics en Chat gecontroleerd.

Geen echte Hugging Face-download of backendkoppeling getest of geïmplementeerd voor Datasets.
